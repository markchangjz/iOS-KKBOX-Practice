//
//  KKAudioQueuePlayer.h
//  KKAudioQueuePlayer
//
//  Created by Oliver Huang on 13/9/18.
//  Copyright (c) 2013年 KKBOX Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol KKAudioQueuePlayerDelegate;

@interface KKAudioQueuePlayer : NSObject

- (id)initWithURL:(NSURL *)inURL;
- (BOOL)prepareToPlay;
- (BOOL)play;
- (void)pause;
- (void)stop;

@property (readonly, getter = isPlaying) BOOL playing;
@property (readonly) NSURL *url;
@property (readonly) NSTimeInterval duration;
@property (nonatomic) NSTimeInterval currentTime;
@property (weak, nonatomic) id<KKAudioQueuePlayerDelegate> delegate;

@end

@protocol KKAudioQueuePlayerDelegate <NSObject>

- (void)audioQueuePlayerDidFinishPlaying:(KKAudioQueuePlayer *)inAudioQueuePlayer sucessfully:(BOOL)inSucessfully;

@end
