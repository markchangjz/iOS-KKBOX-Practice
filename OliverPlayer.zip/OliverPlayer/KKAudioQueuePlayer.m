//
//  KKAudioQueuePlayer.m
//  KKAudioQueuePlayer
//
//  Created by Oliver Huang on 13/9/18.
//  Copyright (c) 2013年 KKBOX Inc. All rights reserved.
//

#import "KKAudioQueuePlayer.h"
#import <AudioToolbox/AudioToolbox.h>

#define LogOnError(where, error)																\
	do {																						\
		if(error) {																				\
			NSLog(@"%s::%@ with error: %@", __FUNCTION__, where, [error localizedDescription]);	\
		}																						\
	}																							\
	while (0)

#define LogOnFailed(where, result)																\
	do {																						\
		if(result != noErr) {																	\
			NSLog(@"%s::%@ with error: %d", __FUNCTION__, where, (int)result);					\
		}																						\
	}																							\
	while (0)

static const NSUInteger KKMaxBufferSize = 0x10000;

@interface KKAudioQueuePlayer () <NSURLConnectionDataDelegate>
{
	NSURLConnection *connection;
	AudioFileStreamID audioFileStream;
	AudioStreamBasicDescription asbd;
	AudioQueueRef outputQueue;
	
	NSMutableData *audioData;
	NSMutableData *packetDescData;
	UInt32 packetsCount;
	NSUInteger currentPacketIndex;
	NSTimeInterval duration;
	NSTimeInterval seekBaseCurrentTime;
	Float64 seekBaseSampleTime;
	
	BOOL didEnqueueFirstBuffer;
	BOOL playing;
	BOOL startAfterNew;
	BOOL queueStartedAfterNew;
}

- (void)asbdReady:(AudioStreamBasicDescription)inASBD;
- (void)newAudioData:(const void* )inBytes length:(UInt32)inLength packetDescriptions:(AudioStreamPacketDescription* )inPacketDescriptions packetsCount:(UInt32)inPacketsCount;
- (void)enqueueBuffer;
- (void)disposeInternalResources;

@end

@implementation KKAudioQueuePlayer

static void KKAudioQueuePlayerAudioFileStreamPropertyHandler(void *inClientData, AudioFileStreamID inAudioFileStream, AudioFileStreamPropertyID inPropertyID, UInt32* ioFlags)
{
	KKAudioQueuePlayer *self = (__bridge KKAudioQueuePlayer *)inClientData;
	switch (inPropertyID) {
		case kAudioFileStreamProperty_FileFormat:
		{
			AudioFileTypeID fileType;
			UInt32 dataSize = sizeof(fileType);
			LogOnFailed(@"AudioFileStreamGetProperty", AudioFileStreamGetProperty(inAudioFileStream, inPropertyID, &dataSize, &fileType));
			UInt8* fcc;
			fcc = (UInt8* )&fileType;
//			NSLog(@"Audio file stream format: %c%c%c%c", fcc[3], fcc[2], fcc[1], fcc[0]);
			break;
		}
		case kAudioFileStreamProperty_DataFormat:
		{
			AudioStreamBasicDescription asbd;
			UInt32 dataSize = sizeof(asbd);
			LogOnFailed(@"AudioFileStreamGetProperty", AudioFileStreamGetProperty(inAudioFileStream, inPropertyID, &dataSize, &asbd));
			[self asbdReady:asbd];
			break;
		}
		default:
		{
			UInt8* fcc;
			fcc = (UInt8* )&inPropertyID; // A four char code
//			NSLog(@"Other audio file stream property: '%c%c%c%c'", fcc[3], fcc[2], fcc[1], fcc[0]);
		}
	}
}

static void KKAudioQueuePlayerAudioFileStreamPacketsHandler(void *inClientData, UInt32 inNumberBytes, UInt32 inNumberPackets, const void* inInputData, AudioStreamPacketDescription* inPacketDescriptions)
{
	KKAudioQueuePlayer *self = (__bridge KKAudioQueuePlayer *)inClientData;
	[self newAudioData:inInputData length:inNumberBytes packetDescriptions:inPacketDescriptions packetsCount:inNumberPackets];
}

static void KKAudioQueueOutput(void *inUserData, AudioQueueRef inAQ, AudioQueueBufferRef inBuffer)
{
	@autoreleasepool {
		KKAudioQueuePlayer *self = (__bridge KKAudioQueuePlayer *)inUserData;
		LogOnFailed(@"AudioQueueFreeBuffer", AudioQueueFreeBuffer(inAQ, inBuffer));
		[self enqueueBuffer];
	}
}

- (void)dealloc
{
	[self disposeInternalResources];
}

- (id)initWithURL:(NSURL *)inURL
{
	if (self = [super init]) {
		url = inURL;
		didEnqueueFirstBuffer = NO;
		audioData = [[NSMutableData alloc] init];
		packetDescData = [[NSMutableData alloc] init];
	}
	return self;
}

- (BOOL)prepareToPlay
{
	OSStatus result = noErr;
	// Already get all data.
	if (duration > 0.) {
		if (!outputQueue) {
			[self asbdReady:asbd];
			[self enqueueBuffer];
			didEnqueueFirstBuffer = YES;
		}
	}
	else if (!audioFileStream) {
		result = AudioFileStreamOpen((__bridge void *)self, KKAudioQueuePlayerAudioFileStreamPropertyHandler, KKAudioQueuePlayerAudioFileStreamPacketsHandler, kAudioFileMP3Type, &audioFileStream);
		if (result != noErr) {
			LogOnFailed(@"AudioFileStreamOpen", result);
			return NO;
		}
		connection = [NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:self.url] delegate:self];
		[connection start];
	}
	return YES;
}

- (BOOL)play
{
	if (![self prepareToPlay]) {
		return NO;
	}
	if (!playing) {
		if (outputQueue) {
			OSStatus result = AudioQueueStart(outputQueue, NULL);
			if (result == noErr) {
				queueStartedAfterNew = YES;
			}
			LogOnFailed(@"AudioQueueStart", result);
		}
		else {
			startAfterNew = YES;
		}
		[self willChangeValueForKey:@"playing"];
		playing = YES;
		[self didChangeValueForKey:@"playing"];
	}
	return YES;
}

- (void)pause
{
	if (playing) {
		LogOnFailed(@"AudioQueuePause", AudioQueuePause(outputQueue));
		[self willChangeValueForKey:@"playing"];
		playing = NO;
		[self didChangeValueForKey:@"playing"];
	}
}

- (void)stop
{
	[self disposeInternalResources];
}

- (BOOL)isPlaying
{
	return playing;
}

- (NSTimeInterval)duration
{
	return duration;
}

- (NSTimeInterval)currentTime
{
	if (!outputQueue) {
		return 0.0;
	}
	if (!didEnqueueFirstBuffer) {
		return 0.0;
	}
	if (!queueStartedAfterNew) {
		return 0.0;
	}
	AudioTimeStamp timeStamp;
	OSStatus result = AudioQueueGetCurrentTime(outputQueue, NULL, &timeStamp, NULL);
	if (result == noErr) {
		NSTimeInterval currentTime = timeStamp.mSampleTime - seekBaseSampleTime;
		currentTime /= asbd.mSampleRate;
		currentTime += seekBaseCurrentTime;
		return currentTime;
	}
	else if (result != kAudioQueueErr_InvalidRunState) {
		LogOnFailed(@"AudioQueueGetCurrentTime", result);
	}
	return 0.0;
}

- (void)setCurrentTime:(NSTimeInterval)inCurrentTime
{
	if (duration > 0.) {
		if (inCurrentTime < 0.) {
			inCurrentTime = 0.;
		}
		else if (inCurrentTime >= duration) {
			inCurrentTime = duration - 0.1;
		}
		
		currentPacketIndex = inCurrentTime * asbd.mSampleRate / asbd.mFramesPerPacket;
		seekBaseCurrentTime = inCurrentTime;
		if (outputQueue) {
			LogOnFailed(@"AudioQueueReset", AudioQueueReset(outputQueue));
			LogOnFailed(@"AudioQueueFlush", AudioQueueFlush(outputQueue));
			AudioTimeStamp timeStamp;
			LogOnFailed(@"AudioQueueGetCurrentTime", AudioQueueGetCurrentTime(outputQueue, NULL, &timeStamp, NULL));
			seekBaseSampleTime = timeStamp.mSampleTime;
			[self enqueueBuffer];
		}
	}
}

#pragma mark - Private methods
- (void)asbdReady:(AudioStreamBasicDescription)inASBD
{
	asbd = inASBD;
	LogOnFailed(@"AudioQueueNewOutput", AudioQueueNewOutput(&inASBD, KKAudioQueueOutput, (__bridge void *)self, NULL, kCFRunLoopCommonModes, 0, &outputQueue));
	if (startAfterNew) {
		OSStatus result = AudioQueueStart(outputQueue, NULL);
		if (result == noErr) {
			queueStartedAfterNew = YES;
		}
		LogOnFailed(@"AudioQueueStart", result);
	}
}

- (void)newAudioData:(const void* )inBytes length:(UInt32)inLength packetDescriptions:(AudioStreamPacketDescription* )inPacketDescriptions packetsCount:(UInt32)inPacketsCount
{
	NSUInteger dataLength = audioData.length;
	for (int i = 0; i < inPacketsCount; ++i) {
		inPacketDescriptions[i].mStartOffset += dataLength;
	}
	@synchronized (self) {
		[audioData appendBytes:inBytes length:inLength];
		[packetDescData appendBytes:inPacketDescriptions length:sizeof(AudioStreamPacketDescription) * inPacketsCount];
		packetsCount += inPacketsCount;
		if (audioData.length >= KKMaxBufferSize && !didEnqueueFirstBuffer) {
			didEnqueueFirstBuffer = YES;
			if (playing) {
				AudioTimeStamp timeStamp;
				LogOnFailed(@"AudioQueueGetCurrentTime", AudioQueueGetCurrentTime(outputQueue, NULL, &timeStamp, NULL));
				seekBaseSampleTime = timeStamp.mSampleTime;
			}
			[self enqueueBuffer];
		}
	}
}

- (void)enqueueBuffer
{
	@synchronized (self) {
		if (currentPacketIndex >= packetsCount)
		{
			// No data
			if (duration > 0.) {
				LogOnFailed(@"AudioQueueFlush", AudioQueueFlush(outputQueue));
				dispatch_async(dispatch_get_main_queue(), ^() {
					[self disposeInternalResources];
					if ([self.delegate respondsToSelector:@selector(audioQueuePlayerDidFinishPlaying:sucessfully:)]) {
						[self.delegate audioQueuePlayerDidFinishPlaying:self sucessfully:YES];
					}
				});
			}
			return;
		}
		UInt32 enqueueLength = 0;
		AudioStreamPacketDescription* packetDescriptions = (AudioStreamPacketDescription* )packetDescData.bytes;
		NSUInteger index;
		NSUInteger startPacketIndex = currentPacketIndex;
		for (index = currentPacketIndex; index < packetsCount; ++index) {
			enqueueLength += packetDescriptions[index].mDataByteSize;
			if (enqueueLength > KKMaxBufferSize) {
				++index;
				break;
			}
		}
		if (enqueueLength == 0) {
			// Data not enough check it later
			NSLog(@"Data not enough check it later");
			double delayInSeconds = 1.0;
			dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
			dispatch_after(popTime, dispatch_get_main_queue(), ^(void) {
				[self enqueueBuffer];
			});
		}
		AudioQueueBufferRef buffer = NULL;
		LogOnFailed(@"AudioQueueAllocateBuffer", AudioQueueAllocateBuffer(outputQueue, enqueueLength, &buffer));
		if (buffer) {
			NSUInteger enqueuePacketsCount = index - startPacketIndex;
			AudioStreamPacketDescription* enqueuePacketDescriptions = (AudioStreamPacketDescription* )malloc(sizeof(AudioStreamPacketDescription) * enqueuePacketsCount);
			memcpy(enqueuePacketDescriptions, packetDescriptions + startPacketIndex, sizeof(AudioStreamPacketDescription) * enqueuePacketsCount);
			for (int i = 0; i < enqueuePacketsCount; ++i) {
				enqueuePacketDescriptions[i].mStartOffset -= packetDescriptions[startPacketIndex].mStartOffset;
			}
			memcpy(buffer->mAudioData, audioData.bytes + packetDescriptions[startPacketIndex].mStartOffset, enqueueLength);
			buffer->mAudioDataByteSize = enqueueLength;
			OSStatus result = AudioQueueEnqueueBuffer(outputQueue, buffer, (UInt32)enqueuePacketsCount, enqueuePacketDescriptions);
			if (result == noErr) {
				currentPacketIndex = index;
				LogOnFailed(@"AudioQueueFlush", AudioQueueFlush(outputQueue));
			}
			else if (result != kAudioQueueErr_EnqueueDuringReset) {
				LogOnFailed(@"AudioQueueEnqueueBuffer", result);
			}
			free(enqueuePacketDescriptions);
		}
	}
}

- (void)disposeInternalResources
{
	if (connection) {
		[connection cancel];
		connection = nil;
	}
	if (audioFileStream) {
		LogOnFailed(@"AudioFileStreamClose", AudioFileStreamClose(audioFileStream));
		audioFileStream = NULL;
	}
	if (outputQueue) {
		LogOnFailed(@"AudioQueueDispose", AudioQueueDispose(outputQueue, true));
		outputQueue = NULL;
	}
	if (duration == 0.) {
		audioData = [[NSMutableData alloc] init];
		packetDescData = [[NSMutableData alloc] init];
		packetsCount = 0;
	}
	queueStartedAfterNew = NO;
	currentPacketIndex = 0;
	seekBaseCurrentTime = 0.;
	seekBaseSampleTime = 0.;
	if (playing) {
		[self willChangeValueForKey:@"playing"];
		playing = NO;
		[self didChangeValueForKey:@"playing"];
	}
	startAfterNew = NO;
	didEnqueueFirstBuffer = NO;
}

#pragma mark - NSURLConnectionDataDelegate
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
	NSLog(@"connection:didFailWithError: %@", [error localizedDescription]);
	if ([self.delegate respondsToSelector:@selector(audioQueuePlayerDidFinishPlaying:sucessfully:)]) {
		[self.delegate audioQueuePlayerDidFinishPlaying:self sucessfully:NO];
	}
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
	if (audioFileStream) {
		LogOnFailed(@"AudioFileStreamParseBytes", AudioFileStreamParseBytes(audioFileStream, (UInt32)data.length, data.bytes, 0));
	}
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
	NSTimeInterval newDuration = packetsCount * asbd.mFramesPerPacket / asbd.mSampleRate;
	if (duration != newDuration) {
		[self willChangeValueForKey:@"duration"];
		duration = newDuration;
		[self didChangeValueForKey:@"duration"];
	}
}

@synthesize url = url;

@end
